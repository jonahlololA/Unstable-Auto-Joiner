# ClickBot

A client-side [Fabric](https://fabricmc.net/) mod for **Minecraft Java 1.21.11**. It reads a Discord
channel, and when a message like `40 wemmbu e` appears, your own character runs to the matching
model on the server and left-clicks it. After the click it switches itself off.

[![build](https://github.com/YOUR-USERNAME/clickbot/actions/workflows/build.yml/badge.svg)](https://github.com/YOUR-USERNAME/clickbot/actions/workflows/build.yml)
[![release](https://img.shields.io/github/v/release/YOUR-USERNAME/clickbot)](https://github.com/YOUR-USERNAME/clickbot/releases/latest)

> **Use at your own risk.** Automating clicks and movement can break a server's rules and can get
> your account banned. Ask the server's admins first, and keep their answer in writing.

## Features
- **Built-in Discord reader.** Paste a bot token and a channel ID into the in-game menu. No Node.js,
  no extra programs.
- **One master switch.** F8 turns everything on or off. It switches itself off after each click.
- **In-game menu (F9)** with every setting as a button, plus a test box.
- **Picks the right model.** The message needs a name and a letter, for example `parrot o`. If it
  cannot tell which model you mean, it does nothing instead of guessing.
- **Strafes in place while waiting**, then sprint-jumps to the model.
- **Configurable keys** for the master switch and the menu.

## What you need
- Minecraft Java Edition **1.21.11** with the **Fabric** loader ([Prism Launcher](https://prismlauncher.org/) sets this up)
- [Fabric API](https://modrinth.com/mod/fabric-api) for 1.21.11
- The ClickBot jar from the [Releases page](../../releases/latest)
- Your own Discord bot (free, about 5 minutes, steps below)

Never share your bot token, and never use someone else's.

## Install
1. Install **Prism Launcher** and sign in with your Microsoft account.
2. **Add Instance** -> Minecraft **1.21.11** -> Loader **Fabric**.
3. Download **Fabric API** for 1.21.11 and the **ClickBot jar** from the Releases page.
4. Select the instance -> **Edit** -> **Mods** -> **Add file(s)** and add both jars.

## Create your Discord bot
1. Go to the [Discord Developer Portal](https://discord.com/developers/applications) -> **New Application**.
2. Open the **Bot** tab -> **Reset Token** -> copy the token (you only see it once).
3. On the same tab, turn on **Message Content Intent** and save.
4. Open **OAuth2 -> URL Generator**, tick scope **bot**, tick permissions **View Channels** and
   **Read Message History**, and open the generated link to add the bot to your server.
   If it is someone else's server, send them the link so an admin can add it.
5. In Discord, turn on **Settings -> Advanced -> Developer Mode**, then right-click the channel to
   watch and choose **Copy Channel ID**.

## First-time setup in game
1. Join the server and press **F9** to open the ClickBot menu.
2. Paste the bot token into the first box and press **Save token**.
3. Paste the channel ID into the second box and press **Save channel**.
4. The status line should say `Discord: built-in`.

Your settings are saved. The token is stored as plain text in the instance's
`config/clickbot.properties`, so never share that file or export your instance with it inside.

## Using it
1. Stand near the models. The game only loads models close to you.
2. Press **F8**. Chat says `MASTER ON` and then `Discord reader connected`.
3. While it waits, your character strafes left and right near one spot.
4. When a message with a model name and a letter appears, your character sprint-jumps to that model
   and clicks it. Then the master switch turns itself off. Press **F8** to start the next round.

**A message needs a name and a letter.**

| Names | Letters |
|---|---|
| `wemmbu`, `spoke`, `flame`, `parrot`, `test`, `test events` | `e`, `m`, `o` |

Examples: `40 spoke o` -> SPOKE [O], `parrot m 30` -> PARROT [M]. A message with only a number does
nothing.

## Keys and commands
Commands run on your computer only; the server never sees them.

| Key / command | What it does |
|---|---|
| **F8** or `/clickbot master` | Master switch on/off |
| **F9** or `/clickbot menu` | Open the menu |
| `/clickbot activate` / `deactivate` | Master switch on / off |
| `/clickbot status` | Show what is on |
| `/clickbot strafe on/off` | Strafe while waiting |
| `/clickbot sprintjump on/off` | Sprint-jump to the model |
| `/clickbot afk on/off` | Step forward and back every 30 seconds (strafe overrides it) |
| `/clickbot test wemmbu e` | Try a target without Discord (master switch must be on) |
| `/clickbot explain wemmbu e` | Show which model it would pick for a target, and why (no click) |
| `/clickbot list` | Save nearby entities to `clickbot-list.txt` for troubleshooting |
| `/clickbot setchannel <id>` | Change the Discord channel |
| `/clickbot cleartoken` | Forget the saved bot token |
| `/clickbot menukey <name>` / `masterkey <name>` | Change the two shortcut keys (F-keys, Insert, Home, Right Shift, ...) |

If a key does nothing (some laptops need Fn + F9), type `/clickbot menu`, then use the **Menu key**
button in the menu to pick a different key.

## Build from source
You only need this if you want to build the jar yourself. You need **Java 25** (for example
[Temurin 25](https://adoptium.net/)).

```
git clone https://github.com/YOUR-USERNAME/clickbot.git
cd clickbot
./gradlew build          # Windows PowerShell: .\gradlew build
```

The jar is in `build/libs/`. Use the one without `sources` or `dev` in its name.

## Troubleshooting

| Problem | Fix |
|---|---|
| No `/clickbot` commands | The mod did not load. Check that Fabric API and ClickBot are both enabled in the Mods tab |
| "Discord rejected the bot token" | Paste the token again in the menu |
| "The bot cannot see that channel" | Give the bot View Channels and Read Message History there |
| "Channel not found" | Check the channel ID, and that the bot is in that server |
| Connected, but messages are ignored | Turn on **Message Content Intent** in the Developer Portal |
| "Can't click ..." | The model is not loaded near you. Walk closer and try `/clickbot list` |
| "Not clicking, to avoid hitting the wrong one" | Two models are too close to tell apart. Run `/clickbot explain <target>` and open an issue with the output |
| "Your hunger is low" | Minecraft does not allow sprinting at hunger 6 or less. Eat something |

## License
[MIT](LICENSE)
